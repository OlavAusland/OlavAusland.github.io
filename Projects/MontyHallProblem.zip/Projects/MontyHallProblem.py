import time
import os
import random

ChangedPoints = 0
StoodPoints = 0

def rooms(change):
    doors = [1, 2, 3]
    car_behind = doors[random.randint(0, len(doors) - 1)]
    selected_door = doors[random.randint(0, len(doors) - 1)]

    for index, element in enumerate(doors):
        if not element == car_behind:
            if not element == selected_door:
                doors.remove(doors[index])
                break

    if(change):
        if selected_door == doors[0]:
            selected_door = doors[1]
        else: selected_door = doors[0]

    if car_behind == selected_door:
        return 1
    return 0

for x in range(0, 10000000):
    ChangedPoints += rooms(True)
    StoodPoints += rooms(False)

print(f"Changed Points: {ChangedPoints}\nStood Points: {StoodPoints}")
input()
