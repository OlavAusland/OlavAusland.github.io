import json
import os


class screen:
    def clear():
        return os.system('CLS')
    

class color():
    black = '\u001b[30m'
    red = '\u001b[31m'
    green = '\u001b[32m'
    yellow = '\u001b[33m'
    blue = '\u001b[34m'
    magneta = '\u001b[35m'
    cyan = '\u001b[36m'
    white = '\u001b[37m'
    reset = '\u001b[0m'

def initialize():
    os.system("title Translater by CarelessDeveloper")

    with open('Database.json') as database:
        data = json.load(database)
        
        height = data["Settings"][1]['lines']
        width = data["Settings"][0]['cols']

        os.system("mode con cols={} lines={}".format(height, width))

    search()

def data():
    spanish, english = [], []
     
    with open("Database.json") as database:
        data = json.load(database)

        for x in data["Spanish"]:
            spanish.append(x)

        for x in data["English"]:
            english.append(x)

    return spanish, english

def search():
    screen.clear()

    spanish, english = data()
    
    search_word = str(input(f"Search for: {color.cyan}"))
    print(f'{color.reset}\n')
    detected_word = False

    for x in range(0, len(spanish)):
        
        if search_word == spanish[x]:
            print(f"{color.cyan}{search_word}{color.reset} in english is: {color.magneta}{english[x]}{color.reset}")
            detected_word = True
            break
        elif search_word == english[x]:
            print(f"{color.cyan}{search_word}{color.reset} in spanish is: {color.magneta}{spanish[x]}{color.reset}")
            detected_word = True
            break
    
    if detected_word == False:
        print(f"{color.cyan}{search_word}{color.reset} is not in the database.")

    print("Do you want to do another search? (y/n)")
    answer = str(input())
    if answer == "y":
        search()
    screen.clear()

initialize()