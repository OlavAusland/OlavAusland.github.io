import requests
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
import datetime

last_price = 0
time = []
prices = []
delay = 10


def get_price():
    global last_price, prices, time
    result = requests.get("https://coinmarketcap.com/currencies/bitcoin/")
    src = result.content
    soup = BeautifulSoup(src, 'html.parser')
    bitcoin_current_price = soup.find("span", class_="h2 text-semi-bold details-panel-item--price__value").text
    if last_price != bitcoin_current_price:
        print("Bitcoin price is: {} \n Time: {}\n-----------------------------"
              .format(bitcoin_current_price, datetime.datetime.now().strftime("%H:%M:%S")))
        last_price = bitcoin_current_price
        time.append("{}\n${}".format(datetime.datetime.now().strftime("%b %d\n %H:%M"), round(float(bitcoin_current_price))))
        prices.append(round(float(bitcoin_current_price)))
        visualize_graph()


def visualize_graph():
    global prices
    while True:
        plt.style.use("bmh")
        plt.title("Bitcoin\nCurrent Time:{}\n{}\nCurrent Price: ${}".format(datetime.datetime.now().strftime("%B/%m/%Y"),
                                                                            datetime.datetime.now().strftime("%H:%M:%S"), prices[prices.__len__() - 1]))
        plt.xlabel("Time")
        plt.ylabel("Price in $")
        plt.plot(time, prices, 0.2, color="0")
        plt.scatter(time, prices, color="0")
        plt.draw()
        plt.pause(delay)
        get_price()


get_price()
