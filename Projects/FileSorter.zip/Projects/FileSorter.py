import glob
import time
import os
import shutil


start_folder = ''
end_folder = ''
files = []


def sort_first_dir():
    try:
        for file in os.listdir(start_folder):
            file_creation = (time.ctime(os.path.getmtime(f'{start_folder}\\{file}'))).split()
            path_dir = f'{end_folder}\\{file_creation[4]}\\{file_creation[1]}'

            try:
                os.makedirs(f'{path_dir}')
            except Exception as error:
                #print(error)
                pass

            if not os.path.exists(f'{path_dir}\\{file}'):
                shutil.move(f'{start_folder}\\{file}', f'{path_dir}\\{file}')
            else: print(f'File Allready Exists In Directory!\n{file}\n')
    except Exception as error:
        print(error)


def sort_subfiles():
    files = list()
    file_names = list()

    for (dirpath, dirnames, filenames) in os.walk(start_folder):
        files += [os.path.join(dirpath, file) for file in filenames]
        file_names += filenames

    if not len(files) == len(file_names):
        print('Error, Please Try Again...')
        time.sleep(2)
        return

    for x in range(len(files)):
        file_creation = (time.ctime(os.path.getmtime(files[x])).split())
        path_dir = f'{end_folder}\\{file_creation[4]}\\{file_creation[1]}'

        try:
            os.makedirs(path_dir)
        except Exception as error:
            #print(error)
            pass

        if not os.path.exists(f'{path_dir}\\{file_names[x]}'):
            shutil.move(files[x], f'{path_dir}\\{file_names[x]}')
        else: print(f'File Allready Exists In Directory!\n{files[x]}\n')


def main():
    global start_folder, end_folder
    start_folder = input('Input Path Of Unsorted Folder: ')
    end_folder = input('Input Path Of The Destination Folder: ')
    os.system('CLS')

    while True:
        print('Enter 1 if you only want to sort the first directory\nEnter 2 if you want to sort all directories')
        answer = input()

        if answer == '1':
            sort_first_dir()
            break
        elif answer == '2':
            sort_subfiles()
            break
        else:
            print('Not A Valid Option!')
            time.sleep(2)
        os.system('CLS')


if __name__ == '__main__':
    main()
