Hey! Thank you for downloading Hangman.

This is created with Python and json for the database

1. You can add more strings / words, themes and guess chances depending on what you want.
2. If you want to add something for the hollidays you could just look at how the structure in json is, 
or read the syntax in 5 minutes, to add more themes and etc.
3. Enjoy