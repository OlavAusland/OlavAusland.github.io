import random as rnd
import json
import os


def get_random_word():
    themes = []
    words = []

    with open('GameOptions.json') as file:
        data = json.load(file)

        for x in range(0, len(data["Theme"])):
            for z in data["Theme"][x]:
                themes.append(z)
        
        random_theme = rnd.randrange(0, len(themes))

        for x in data["Theme"][random_theme][themes[random_theme]]:
            words.append(x)
        
    return themes[random_theme], words[rnd.randrange(0, len(words))], data["GuessChances"]


def game():
    os.system("CLS")
    theme, word, guesses = get_random_word()
    hidden_word = []
    count = len(word)

    for x in range(0, len(word)):
        hidden_word.append("_")

    for x in range(0, len(word)):
        if word[x] == " ":
            hidden_word[x] = word[x]
            count -= 1
    
    print("The theme is: {}".format(theme))
    print(hidden_word)
    
    while True:
        print("Guess a character.")
        guess = str(input())
        
        isCorrect = False
        for x in range(0, len(word)):
            if word[x].lower() == guess or word[x].upper() == guess:
                hidden_word[x] = word[x]
                count -= 1
                isCorrect = True
            if x == len(word) - 1:
                if isCorrect == False:
                    guesses -= 1
        
        os.system('CLS')
        if guesses <= 0:
            print("You lost, the word was: {}\nDo you want to play again? (y/n)".format(word))
            answer = str(input())
            if(answer == "y"):
                game()
            break
        else:
            print("The theme is: {}".format(theme))
            print(hidden_word)

        if count <= 0:
            print("You won with {} extra guess(es) left!\nThe word was {}.\n\nDo you want to play again? (y/n)".format(guesses, word))
            answer = str(input())
            if(answer == "y"):
                game()
            break

def initialize():
    height, width = 0, 0

    with open('GameOptions.json') as file:
        data = json.load(file)

        height = data['Screen'][0]['cols']
        width = data['Screen'][0]['lines']

    os.system("title Hangman by CarelessDeveloper")
    os.system("mode con cols={} lines={}".format(height, width))

    game()

initialize()